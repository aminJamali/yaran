import 'package:flutter/material.dart';

class UserLoginDto {
  final String userName, password;

  UserLoginDto(this.userName, this.password);
}
