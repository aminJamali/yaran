import 'package:flutter/material.dart';

class DeleteLoanDto {
  final String apiToken;
  final int id;

  DeleteLoanDto({this.apiToken, this.id});
}
