class TransactionDeleteDto {
  final String apiToken;
  final int id;

  TransactionDeleteDto({this.apiToken, this.id});
}
