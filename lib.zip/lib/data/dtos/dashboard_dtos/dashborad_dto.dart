class DashBoradDto {
  final String apiToken;

  DashBoradDto(this.apiToken);
}
