class DoInstallmentDto {
  final String apiToken;
  final int id;

  DoInstallmentDto({this.apiToken, this.id});
}
