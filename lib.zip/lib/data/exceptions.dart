class Exceptions {
  final String message;

  Exceptions({this.message});
}
