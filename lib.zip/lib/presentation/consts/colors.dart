import 'package:flutter/material.dart';

Color maincolor = Color(0xFF3366FF);
Color bodycolor = Color(0xffedefff);
